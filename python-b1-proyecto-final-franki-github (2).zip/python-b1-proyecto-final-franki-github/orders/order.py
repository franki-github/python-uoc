


from users import *
from products import *

class Order:
  def __init__(self, cashier:Cashier, customer:Customer):
    self.cashier = cashier
    self.customer = customer
    self.products = []

  
  def add(self, product):
        #Write your code here

    #agregamos el producto a la lista de productos
    self.products.append(product)
    #imprimimos el producto agregado
    print(f"Product {product.name} added to the order.")

    #imprimimos la lista de productos
    print("Products in the order:")
    for product in self.products:
          print(product.describe())
    #imprimimos el total de la orden
    print(f"Total price: {self.calculateTotal()}")
     
    pass

  def calculateTotal(self) -> float:
    #Write your code here
    #inicializamos el total a 0
    total = 0
    #recorremos la lista de productos
    for product in self.products:
      #sumamos el precio de cada producto al total
      total += product.price
    #devolvemos el total
    return total
    #imprimimos el total
    print(f"Total price: {total}")
    
    pass
  
  def show(self):    
    print("Hello : "+self.customer.describe())
    print("Was attended by : "+self.cashier.describe())
    for product in self.products:
      print(product.describe())
    print(f"Total price : {self.calculateTotal()}")
