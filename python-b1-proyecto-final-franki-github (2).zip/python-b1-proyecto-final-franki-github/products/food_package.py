

#Write your code 
from abc import ABC, abstractmethod

class FoodPackage (ABC): 
    @abstractmethod
    def pack(self)  -> str:
        pass
    @abstractmethod
    def material(self) -> str:
        pass
    def describe(self):
        return f"Empaque: {self.pack()} , Material: {self.material()}"    
    
class Wrapping(FoodPackage):  
  #Write your code
    def pack(self): 
       return "Food Wrap Paper" 
    def material(self): 
       return "Aluminium" 
  
    pass

class Bottle(FoodPackage):  
  #Write your code 
    def pack(self): 
       return "Bottle" 
    def material(self): 
       return "Carton"
    pass
      
class Glass(FoodPackage):  
  #Write your code here
    def pack(self): 
        return "Glass" 
    def material(self): 
        return "Cristal"
  
    pass

class Box(FoodPackage):  
  #Write your code 
    def pack(self): 
        return "Box" 
    def material(self): 
        return "Papel duro"
  
    pass